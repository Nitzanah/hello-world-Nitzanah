from flask import Flask, render_template, redirect, url_for

app = Flask(__name__)


@app.route('/')
def welcome():
    return render_template('html.html')


@app.route('/contact')
def contact():
    return render_template('ContctForm.html')


@app.route('/list')
def list():
    return render_template('Userlist.html')


@app.route('/assignment8')
def assignment8():
    user = 'Nitzan Aharoni'
    hobbies = ['Diving', 'Jewlery Making', 'Sleeping', 'Traveling', 'Dancing']
    return render_template('assignment8.html', user=user, hobbies=hobbies)




if __name__ == '_main_':
    app.run()
