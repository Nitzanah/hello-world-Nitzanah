from flask import Flask, Blueprint, render_template, redirect, request, session, url_for, make_response
from flask_mysqldb import MySQL

mysql = MySQL()

from assignment10.app import assignment10

def init_app():
	app = Flask(__name__)
	app.secret_key = "abc"
	app.config['MYSQL_USER'] = "root"
	app.config['MYSQL_PASSWORD'] = "root"
	app.config['MYSQL_DB'] = "assignment10"
	app.config['MYSQL_HOST'] = "localhost"
	mysql.init_app(app)
	app.register_blueprint(assignment10, url_prefix="/assignment10")
	return app

app = init_app()

@app.route('/')
def index():
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template('html.html', greeting=greeting)

@app.route('/<file>')
def load_any_file(file):
	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	if file.find(".html")!=-1:
		return render_template(file, greeting=greeting)
	return redirect(url_for('static', filename=file))




usersList = [{"name": "Nitzan", "email": "nitzan94@gmail.com"},
             {"name": "noa manor", "email": "noa.manor@reqres.in"},
             {"name": "itai manor", "email": "itai.manor@reqres.in"}]

@app.route('/assignment9', methods=["GET", "POST"])
def assignment9():
	listToSend = [ ]
	if request.args.get("search")!=None:
		searchVal = request.args.get("search")
		for x in usersList:
			if x["name"].find(searchVal)!=-1 or x["email"].find(searchVal)!=-1:
				listToSend.append(x)
	elif "name" in request.form:
		usersList.append({ "name":request.form["name"], "email":request.form["email"] })
		session["greeting"] = request.form["name"]
	elif "logout" in request.form:
		session.clear()

	greeting = ""
	if "greeting" in session:
		greeting = session["greeting"]
	return render_template("assignment9.html", users=listToSend, greeting=greeting)

if __name__ == '__main__':
	app.run(port=3000)
