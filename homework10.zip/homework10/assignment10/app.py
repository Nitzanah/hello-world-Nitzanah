from flask import Blueprint, render_template, request, redirect

assignment10 = Blueprint('assignment10', __name__, static_folder='static', template_folder='templates')

from app import mysql

@assignment10.route("/assignment10")
def index():
	cur = mysql.connection.cursor()
	cur.execute("SELECT * FROM user")
	out = list(cur.fetchall())
	cur.close()
	return render_template("assignment10.html", userList=out)

@assignment10.route("/add", methods=["POST"])
def add():
	cur = mysql.connection.cursor()
	out = cur.execute("INSERT INTO user(name, email) VALUES(%s, %s)", (request.form["name"], request.form["email"],))
	if out==0:
		return "Could not add record"
	mysql.connection.commit()
	cur.close()
	return redirect("/assignment10/assignment10")

@assignment10.route("/update", methods=["POST"])
def update():
	cur = mysql.connection.cursor()
	out = cur.execute("UPDATE user SET name=%s, email=%s WHERE id=%s", (request.form["name"], request.form["email"],request.form["id"],))
	if out==0:
		return "Could not update record"
	mysql.connection.commit()
	cur.close()
	return redirect("/assignment10/assignment10")

@assignment10.route("/delete", methods=["POST"])
def delete():
	cur = mysql.connection.cursor()
	out = cur.execute("DELETE FROM user WHERE id=%s", (request.form["id"],))
	if out==0:
		return "Could not delete record"
	mysql.connection.commit()
	cur.close()
	return redirect("/assignment10/assignment10")

